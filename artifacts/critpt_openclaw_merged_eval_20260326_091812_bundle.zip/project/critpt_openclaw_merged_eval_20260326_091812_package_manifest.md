# CritPt OpenClaw 提交包说明

## 对应 run

- 正式提交 run：`merged_eval_20260326_091812`
- 基线 generation：`manual_gen_20260325_081355`
- 失败题补跑：`rerun_failed_20260325_081355`

## 包内内容

- `critpt_openclaw_gene_accuracy_token_analysis_20260326.md`
  - 当时的分析说明文档
- `benchmarks/critpt-openclaw/results/generations/merged_eval_20260326_091812/run_summary.json`
  - 合并后的 70 题提交摘要
- `benchmarks/critpt-openclaw/results/generations/merged_eval_20260326_091812/submissions/`
  - 合并后的 70 道题提交文件
- `benchmarks/critpt-openclaw/results/generations/merged_eval_20260326_091812/submissions.__grading_sanitized__/`
  - 用于 grading 的清洗后提交文件
- `benchmarks/critpt-openclaw/results/evaluations/merged_eval_20260326_091812/aggregate_report.json`
  - 官方评测返回的汇总结果

## 已确认信息

- `run_summary.json` 里记录的 `submission_count = 70`
- `aggregate_report.json` 里记录的：
  - `total_submissions = 70`
  - `accuracy = 0.2714285714285714`
  - `timeout_rate = 0`
  - `judge_error_count = 0`
